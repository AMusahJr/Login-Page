var form = document.getElementById("signIn_form");

form.addEventListener("submit", function(event){
   event.preventDefault();
   const email=document.getElementById("mail");
   const regex_email=/\w+\.\w+@\w+\.\w+\.\w+ |\w+@\w+\.\w+/;
   const password=document.getElementById("password");
   const regex_password= /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&_-])[A-Za-z\d@$!%*?&]{8,}$/;
   if(regex_email.test(email.value)){ 
       email.style.border="2px solid green";
   }
   else{
       email.style.border="2px solid red";
   }


   if(regex_password.test(password.value)){ 
       password.style.border="2px solid green";
   }
   else{
       password.style.border="2px solid red";
       
   }
}
);